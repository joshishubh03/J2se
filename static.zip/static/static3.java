
class TestMain{
  static{
    System.out.println("Outer-Block");
  }
  public static void main(String args[]){
     System.out.println("Main Executed.....");
  }
}
