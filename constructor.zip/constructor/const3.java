class A{
  
}

class TestMain{
  public static void main(String args[]){
    new A();
  }
}
