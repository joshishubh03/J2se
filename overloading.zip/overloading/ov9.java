class A{
  public void m1(int a,float... x,int... y){
  
  }
}

class TestMain{
  public static void main(String args[]){
      A obj = new A();
      obj.m1(2,7,3,4,5,56,6,6);
  }
}
