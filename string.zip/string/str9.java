class TestMain{
   public static void main(String args[]){
     String s1 = "         InfoBeans          ";
     System.out.println("$"+s1+"$");
   
     s1 = s1.trim();
     System.out.println("$"+newString+"$");
   }
}
