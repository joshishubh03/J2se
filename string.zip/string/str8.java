class TestMain{
   public static void main(String args[]){
     String s1 = "InfoBeans Foundation";
     
     //String newString = s1.substring(4);
     String newString = s1.substring(4,9);
     System.out.println(newString);
   }
}
